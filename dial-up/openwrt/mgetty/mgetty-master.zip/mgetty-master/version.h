#define VERSION_LONG "interim release 1.1.37-Jun05";
#define VERSION_SHORT "1.1.37"
extern char * mgetty_version;
